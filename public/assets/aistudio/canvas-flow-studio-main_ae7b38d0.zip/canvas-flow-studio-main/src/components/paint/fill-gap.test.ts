import { describe, expect, it } from 'vitest';
import { fillMask } from './fill';

// 40x40 white canvas with a black square outline (10..29) that has a 2px gap in the top edge.
function boxWithGap() {
  const w = 40, h = 40;
  const src = new Uint8ClampedArray(w * h * 4).fill(255);
  const wall = (x: number, y: number) => { const p = (y * w + x) * 4; src[p] = 0; src[p + 1] = 0; src[p + 2] = 0; };
  for (let i = 10; i < 30; i++) { if (i !== 19 && i !== 20) wall(i, 10); wall(i, 29); wall(10, i); wall(29, i); }
  return { src, w, h };
}
const count = (m: Uint8Array) => m.reduce((a, b) => a + b, 0);

describe('ColorDrop smart gap closing', () => {
  it('leaks through a 2px gap without gap closing', () => {
    const { src, w, h } = boxWithGap();
    expect(fillMask(src, w, h, 20, 20, 10, 0)[2 * w + 2]).toBe(1);
  });
  it('stays inside the shape when the gap is closed', () => {
    const { src, w, h } = boxWithGap();
    const m = fillMask(src, w, h, 20, 20, 10, 2);
    expect(m[2 * w + 2]).toBe(0);
    // still fills right up to the lines (interior is 18x18)
    expect(m[11 * w + 11]).toBe(1);
    expect(count(m)).toBeGreaterThanOrEqual(18 * 18);
  });
});
