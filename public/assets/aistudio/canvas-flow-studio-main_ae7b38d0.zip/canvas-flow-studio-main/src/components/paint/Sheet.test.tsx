import { fireEvent, render, screen, act } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { Sheet } from './Sheet';

afterEach(() => vi.useRealTimers());

describe('sheet gestures', () => {
  it('increases menu height when resized upward', () => {
    render(<Sheet label="Test menu" height="300px" onClose={() => {}}>Contents</Sheet>);
    vi.spyOn(screen.getByRole('dialog'), 'getBoundingClientRect').mockReturnValue({ height: 300 } as DOMRect);
    const handle = screen.getByRole('button', { name: 'Resize Test menu' });
    fireEvent.keyDown(handle, { key: 'ArrowUp' });
    expect(screen.getByRole('dialog').style.height).toBe('360px');
  });
  it('dismisses the menu with Escape after its closing transition', () => {
    vi.useFakeTimers();
    vi.stubGlobal('matchMedia', () => ({ matches: false }));
    const close = vi.fn();
    render(<Sheet label="Dismiss menu" onClose={close}>Contents</Sheet>);
    fireEvent.keyDown(screen.getByRole('dialog', { name: 'Dismiss menu' }), { key: 'Escape' });
    expect(close).not.toHaveBeenCalled();
    act(() => vi.advanceTimersByTime(240));
    expect(close).toHaveBeenCalledOnce();
    vi.unstubAllGlobals();
  });
});