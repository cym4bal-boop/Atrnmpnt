import { describe, expect, it } from 'vitest';
import { cornerSnap } from './docking';

const VW = 1000, VH = 800, W = 244, H = 150;

describe('corner snapping (toolbar + layers panel)', () => {
  it('seats the panel in the nearest corner with the edge margin', () => {
    expect(cornerSnap({ x: 700, y: 40 }, W, H, VW, VH)).toEqual({ x: VW - 14 - W, y: 14, l: false, r: true, t: true, b: false });
    expect(cornerSnap({ x: 30, y: 700 }, W, H, VW, VH)).toEqual({ x: 14, y: VH - 14 - H, l: true, r: false, t: false, b: true });
  });
  it('never seats at an edge or screen center — a mid-edge drag still lands in a corner', () => {
    const midLeft = cornerSnap({ x: 4, y: VH / 2 - H / 2 }, W, H, VW, VH);
    expect(midLeft.l).toBe(true);
    expect(midLeft.t !== midLeft.b).toBe(true); // one vertical corner flag, never centered
    expect([midLeft.y, midLeft.y + H]).not.toContain(VH / 2 - H / 2);
    const midTop = cornerSnap({ x: VW / 2 - W / 2, y: 4 }, W, H, VW, VH);
    expect(midTop.t).toBe(true);
    expect(midTop.l !== midTop.r).toBe(true);
  });
  it('clamps oversized panels inside the viewport margins', () => {
    const s = cornerSnap({ x: -500, y: -500 }, W * 4, H * 4, VW, VH);
    expect(s.x).toBe(14);
    expect(s.y).toBe(14);
  });
});
