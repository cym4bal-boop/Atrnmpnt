// @ts-nocheck -- strict index checks relaxed for canvas pixel code.
// Dab-based brush engine: brush definitions, tinted tip cache and stamping.
export type BrushDef = {
  id: string;
  name: string;
  category: string;
  spacing: number; // fraction of size between dabs
  hardness: number; // 0 soft – 1 hard
  flow: number; // per-dab alpha 0-1
  sizePressure: number; // 0-1 how much pressure shrinks size
  opacityPressure: number; // 0-1 how much pressure reduces flow
  jitter: number; // size jitter 0-1
  scatter: number; // position scatter, fraction of size
  grain: number; // 0-1 noisy texture amount
  roundness: number; // 1 round, <1 flattened
  angle: number; // tip angle in degrees (for flat tips)
  rotateRandom: boolean;
  taper: number; // 0-1 taper at stroke start
  maxSize: number; // px at 100% size slider
};

const base: Omit<BrushDef, 'id' | 'name' | 'category'> = {
  spacing: 0.08, hardness: 0.85, flow: 1, sizePressure: 0.6, opacityPressure: 0, jitter: 0,
  scatter: 0, grain: 0, roundness: 1, angle: 0, rotateRandom: false, taper: 0.4, maxSize: 80,
};

export const brushLibrary: BrushDef[] = [
  { ...base, id: 'magpie', name: 'Magpie', category: 'Markers', roundness: .35, angle: -12, grain: .3, flow: .75, maxSize: 110 },
  { ...base, id: 'sleepyhead', name: 'Sleepyhead', category: 'Markers', roundness: .5, grain: .82, opacityPressure: .4, hardness: .65, maxSize: 130 },
  { ...base, id: 'apsley', name: 'Apsley', category: 'Markers', roundness: .3, angle: 12, grain: .25, flow: .9, maxSize: 120 },
  { ...base, id: 'flynn', name: 'Flynn', category: 'Markers', roundness: .25, angle: -15, hardness: .95, flow: .95, maxSize: 150 },
  { ...base, id: 'centurion', name: 'Centurion', category: 'Markers', roundness: .35, grain: .6, flow: .65, maxSize: 135 },
  { ...base, id: 'pastel', name: 'Soft Pastel', category: 'Pastels', grain: .9, flow: .45, hardness: .6, rotateRandom: true, maxSize: 100 },
  { ...base, id: 'oil', name: 'Oil Paint', category: 'Oils', roundness: .4, grain: .4, flow: .85, maxSize: 140 },
  { ...base, id: 'hb-pencil', name: '6B Pencil', category: 'Sketching', spacing: 0.1, hardness: 0.6, flow: 0.55, sizePressure: 0.3, opacityPressure: 0.7, grain: 0.75, rotateRandom: true, maxSize: 30 },
  { ...base, id: 'narinder', name: 'Narinder Pencil', category: 'Sketching', spacing: 0.12, hardness: 0.7, flow: 0.4, sizePressure: 0.2, opacityPressure: 0.8, grain: 0.85, rotateRandom: true, maxSize: 20 },
  { ...base, id: 'studio-pen', name: 'Studio Pen', category: 'Inking', spacing: 0.05, hardness: 0.98, flow: 1, sizePressure: 0.85, taper: 0.7, maxSize: 60 },
  { ...base, id: 'technical-pen', name: 'Technical Pen', category: 'Inking', spacing: 0.05, hardness: 1, flow: 1, sizePressure: 0, taper: 0, maxSize: 40 },
  { ...base, id: 'dry-ink', name: 'Dry Ink', category: 'Inking', spacing: 0.06, hardness: 0.92, flow: 0.9, sizePressure: 0.5, grain: 0.35, rotateRandom: true, maxSize: 50 },
  { ...base, id: 'soft-brush', name: 'Soft Brush', category: 'Airbrushing', spacing: 0.06, hardness: 0, flow: 0.12, sizePressure: 0.1, opacityPressure: 0.6, taper: 0, maxSize: 260 },
  { ...base, id: 'hard-airbrush', name: 'Hard Airbrush', category: 'Airbrushing', spacing: 0.06, hardness: 0.55, flow: 0.25, sizePressure: 0.1, opacityPressure: 0.5, taper: 0, maxSize: 200 },
  { ...base, id: 'round-brush', name: 'Round Brush', category: 'Painting', spacing: 0.04, hardness: 0.9, flow: 0.9, sizePressure: 0.7, taper: 0.5, maxSize: 120 },
  { ...base, id: 'gouache', name: 'Gouache', category: 'Painting', spacing: 0.05, hardness: 0.7, flow: 0.55, sizePressure: 0.4, opacityPressure: 0.4, grain: 0.45, roundness: 0.75, angle: 30, maxSize: 140 },
  { ...base, id: 'flat-brush', name: 'Flat Brush', category: 'Painting', spacing: 0.03, hardness: 0.8, flow: 0.7, sizePressure: 0.2, roundness: 0.25, angle: 45, taper: 0.2, maxSize: 140 },
  { ...base, id: 'charcoal', name: 'Vine Charcoal', category: 'Charcoals', spacing: 0.12, hardness: 0.4, flow: 0.45, sizePressure: 0.3, opacityPressure: 0.6, grain: 0.95, jitter: 0.25, scatter: 0.06, rotateRandom: true, maxSize: 90 },
  { ...base, id: 'spray', name: 'Medium Nozzle', category: 'Spraypaints', spacing: 0.2, hardness: 0.3, flow: 0.18, sizePressure: 0.2, grain: 1, jitter: 0.5, scatter: 0.4, rotateRandom: true, taper: 0, maxSize: 200 },
  { ...base, id: 'calligraphy', name: 'Script', category: 'Calligraphy', spacing: 0.03, hardness: 1, flow: 1, sizePressure: 0.75, roundness: 0.3, angle: 45, taper: 0.6, maxSize: 60 },
  { ...base, id: 'monoline', name: 'Monoline', category: 'Calligraphy', spacing: 0.04, hardness: 1, flow: 1, sizePressure: 0, taper: 0, maxSize: 50 },
];

export const brushCategories = ['Pens', 'Inks', 'Markers', 'Pastels', 'Oils', 'Paints', 'Gouache', 'Sketching', 'Airbrushing', 'Charcoals', 'Spraypaints', 'Calligraphy'];
export function brushesInCategory(category: string) {
  return brushLibrary.filter((b) => category === 'Pens' ? b.category === 'Inking' && b.id !== 'dry-ink' : category === 'Inks' ? b.id === 'dry-ink' : category === 'Paints' ? b.category === 'Painting' && b.id !== 'gouache' : category === 'Gouache' ? b.id === 'gouache' : b.category === category);
}

const TIP = 128;
// key: `${brushId}@${px}` — the tip shape is regenerated at the requested
// resolution so previews can render a brush at its true size instead of
// upscaling the 128px cache (which looked pixelated).
const shapeCache = new Map<string, HTMLCanvasElement>();
const tintCache = new Map<string, HTMLCanvasElement>();

function seeded(seed: number) {
  let s = seed;
  return () => ((s = (s * 16807) % 2147483647) / 2147483647);
}

function tipShape(brush: BrushDef, px = TIP) {
  const key = `${brush.id}@${px}`;
  const cached = shapeCache.get(key);
  if (cached) return cached;
  const c = document.createElement('canvas');
  c.width = c.height = px;
  const ctx = c.getContext('2d')!;
  const r = px / 2;
  const g = ctx.createRadialGradient(r, r, 0, r, r, r);
  const solid = Math.max(0, Math.min(0.98, brush.hardness));
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(solid, 'rgba(255,255,255,1)');
  g.addColorStop(Math.min(1, solid + 0.02), solid > 0.95 ? 'rgba(255,255,255,0)' : 'rgba(255,255,255,0.85)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.save();
  ctx.translate(r, r);
  ctx.rotate((brush.angle * Math.PI) / 180);
  ctx.scale(1, brush.roundness);
  ctx.translate(-r, -r);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(r, r, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  if (brush.grain > 0) {
    const img = ctx.getImageData(0, 0, px, px);
    const rand = seeded(brush.id.length * 7919 + 13);
    for (let i = 3; i < img.data.length; i += 4) {
      const n = rand();
      img.data[i] = img.data[i] * (n < brush.grain * 0.7 ? n * 0.6 : 1);
    }
    ctx.putImageData(img, 0, 0);
  }
  if (shapeCache.size > 24) shapeCache.clear();
  shapeCache.set(key, c);
  return c;
}

/** Tinted brush tip. `px` renders the tip natively at that diameter (0 = default 128). */
export function brushTip(brush: BrushDef, color: string, px = TIP) {
  const key = `${brush.id}|${color}|${px}`;
  const cached = tintCache.get(key);
  if (cached) return cached;
  const c = document.createElement('canvas');
  c.width = c.height = px;
  const ctx = c.getContext('2d')!;
  ctx.drawImage(tipShape(brush, px), 0, 0);
  ctx.globalCompositeOperation = 'source-in';
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, px, px);
  if (tintCache.size > 40) tintCache.clear();
  tintCache.set(key, c);
  return c;
}

export function eraserTip(brush: BrushDef, px = TIP) {
  return brushTip(brush, '#000000', px);
}

export type DabInput = { x: number; y: number; pressure: number; travelled: number };

/** Stamps one dab of the brush. size = diameter in canvas px at full pressure. */
export function stampDab(ctx: CanvasRenderingContext2D, tip: HTMLCanvasElement, brush: BrushDef, d: DabInput, size: number, flowScale = 1) {
  const taperLen = size * 6 * brush.taper;
  const taper = taperLen > 0 ? Math.min(1, 0.15 + d.travelled / taperLen) : 1;
  const p = Math.max(0.05, Math.min(1, d.pressure));
  let s = size * (1 - brush.sizePressure + brush.sizePressure * p) * taper;
  if (brush.jitter) s *= 1 - Math.random() * brush.jitter;
  s = Math.max(0.6, s);
  const alpha = brush.flow * (1 - brush.opacityPressure + brush.opacityPressure * p) * flowScale;
  let x = d.x, y = d.y;
  if (brush.scatter) {
    x += (Math.random() - 0.5) * size * brush.scatter * 2;
    y += (Math.random() - 0.5) * size * brush.scatter * 2;
  }
  ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
  if (brush.rotateRandom) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(Math.random() * Math.PI * 2);
    ctx.drawImage(tip, -s / 2, -s / 2, s, s);
    ctx.restore();
  } else {
    ctx.drawImage(tip, x - s / 2, y - s / 2, s, s);
  }
  return s;
}

/** Small preview stroke for the brush library list. */
export function drawBrushPreview(canvas: HTMLCanvasElement, brush: BrushDef, color = '#1c1c1e') {
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const tip = brushTip(brush, color);
  const w = canvas.width, h = canvas.height;
  const size = Math.min(h * 0.55, brush.maxSize * 0.5 + 6);
  let travelled = 0, prev: { x: number; y: number } | null = null;
  for (let t = 0; t <= 1; t += 0.004) {
    const x = 10 + t * (w - 20);
    const y = h / 2 + Math.sin(t * Math.PI * 2) * h * 0.18;
    if (prev) travelled += Math.hypot(x - prev.x, y - prev.y);
    prev = { x, y };
    const pressure = Math.sin(t * Math.PI);
    stampDab(ctx, tip, brush, { x, y, pressure, travelled }, size, 1);
  }
  ctx.globalAlpha = 1;
}
