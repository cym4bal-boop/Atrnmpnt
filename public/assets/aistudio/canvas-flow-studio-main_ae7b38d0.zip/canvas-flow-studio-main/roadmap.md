# Roadmap — Aeternum Paint Studio (new project)

Migrated from procreate-style-canvas-studio-main.zip (Oct 30). No DB/auth in source — pure client app.

## Done this round
- [x] Migrated full source, deps (ag-psd, jszip), 31 tests pass, typecheck clean
- [x] Off-screen clamping: floaters (mount/drag/pinch/resize), loupe, slider pair, toolbar, layers bar
- [x] Stack sheets no longer crop (object-fit contain); fan rotation increased to ±7.5° (hover ±10°)
- [x] 3-finger scrub sideways/vertical → clear active layer (once per gesture)
- [x] 3-finger swipe down → Cut/Copy/Paste menu for current layer
- [x] 4-finger tap → toggle fullscreen
- [x] Layers unlimited already (no cap in code) — confirmed nothing to change
- [x] Hold canvas + tap another canvas/stack (or hold stack + tap canvas) → instant stack
- [x] Stack name + fade moved inside the top canvas sheet so it fits exactly
- [x] Layer bar always opens compact
- [x] PiP: resize now grows around the fingers (dynamic pinch origin), clamp on mount/drag/pinch/resize
- [x] Per-palette picture-in-picture button (single-palette floater)
- [x] ColorDrop pill: Edge detection toggle button (persistent pref) + toggle in canvas Settings
- [x] Sliders (opacity/size) pinch-resizable with on-screen clamp
- [x] Actions window: Prefs renamed to Settings (incl. hint texts)
- [x] Select mode → Stack button; stacks pour into canvases, not into stacks
- [x] Stack window has bottom action row; content scrolls under it with fade
- [x] Colors window opens tall with no scrolling except Palettes
- [x] Liquid-glass consistency pass on new surfaces

## Open
- [ ] Replace brush library with the given brushes — BLOCKED: no brush zips attached; waiting for upload
- [ ] Screenshot-dependent polish (stack name shade look) — screenshots not attached; implemented from description, needs user review
- [ ] Multi-touch gestures are code-verified + typechecked, but not yet exercised on a real touch device
