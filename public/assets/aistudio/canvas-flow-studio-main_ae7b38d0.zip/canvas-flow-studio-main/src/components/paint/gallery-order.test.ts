import { describe, expect, it } from 'vitest';
import { moveEntry, normalize, stackOnto, unstack, type Entry } from './gallery-order';

const a = (id: string): Entry => ({ t: 'a', id });

describe('gallery order', () => {
  it('opening a canvas does not move it: saved order wins over recency', () => {
    const order = [a('x'), a('y'), a('z')];
    // 'z' was just opened, so it is now first by recency
    expect(normalize(order, ['z', 'x', 'y']).map((e) => (e.t === 'a' ? e.id : ''))).toEqual(['x', 'y', 'z']);
  });

  it('new canvases appear first', () => {
    expect(normalize([a('x')], ['n', 'x'])[0]).toEqual(a('n'));
  });

  it('dropping one canvas on another makes a stack named Stack', () => {
    const out = stackOnto([a('x'), a('y'), a('z')], 'z', 'x', 's1');
    expect(out).toEqual([{ t: 's', id: 's1', name: 'Stack', items: ['x', 'z'] }, a('y')]);
  });

  it('dropping a canvas on a stack adds it to the stack', () => {
    const out = stackOnto([{ t: 's', id: 's1', name: 'Stack', items: ['x'] }, a('y')], 'y', 'stack:s1', 'n');
    expect(out).toEqual([{ t: 's', id: 's1', name: 'Stack', items: ['x', 'y'] }]);
  });

  it('taking the last canvas out of a stack removes the stack', () => {
    expect(unstack([{ t: 's', id: 's1', name: 'Stack', items: ['x'] }], 's1', 'x')).toEqual([a('x')]);
  });

  it('reorders entries', () => {
    expect(moveEntry([a('x'), a('y'), a('z')], 'x', 2).map((e) => (e.t === 'a' ? e.id : ''))).toEqual(['y', 'z', 'x']);
  });
});
