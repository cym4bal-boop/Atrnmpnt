/* Pinch-to-resize for floating UI (toolbar, layers bar, floating color pickers).
 * Two fingers on the element whose distance changes by more than a small dead
 * zone scale it; the size is kept per key on this device. Moving with two fingers
 * at a steady distance is left to the element's own drag logic.
 *
 * origin 'pinch' keeps the point between the two fingers stationary while the
 * element grows, so a picker never slides out from under the fingers. */
import { useEffect, useRef, type RefObject } from 'react';

export const clampScale = (s: number, min = 0.7, max = 1.5) => Math.max(min, Math.min(max, s));

/** Scale after a pinch: ignores small distance changes so two-finger drags don't resize. */
export function pinchScale(s0: number, d0: number, d: number, min = 0.7, max = 1.5, dead = 0.08) {
  if (d0 <= 0) return s0;
  const r = d / d0;
  if (Math.abs(r - 1) < dead) return s0;
  // remove the dead zone so the size doesn't jump when it kicks in
  const eff = r > 1 ? r - dead : r + dead;
  return clampScale(s0 * eff, min, max);
}

export function readScale(key: string, fallback = 1) {
  try { const v = Number(localStorage.getItem(key)); return v > 0 ? clampScale(v) : fallback; } catch { return fallback; }
}

type O = { x: number; y: number };

export function usePinchScale(ref: RefObject<HTMLElement | null>, key: string, origin = '0 0', onScale?: (s: number) => void) {
  const scale = useRef(readScale(key));
  const cb = useRef(onScale); cb.current = onScale;
  const orig = useRef<O | null>(null); // current local transform origin (px) when origin === 'pinch'
  useEffect(() => {
    const apply = () => {
      const el = ref.current;
      if (!el) return;
      el.style.scale = String(scale.current);
      if (origin !== 'pinch') { el.style.transformOrigin = origin; return; }
      if (!orig.current) {
        // start centred
        orig.current = { x: el.offsetWidth / 2, y: el.offsetHeight / 2 };
      }
      el.style.transformOrigin = `${orig.current.x}px ${orig.current.y}px`;
    };
    apply();
    const pts = new Map<number, { x: number; y: number }>();
    let g: { d0: number; s0: number; m0: O } | null = null;
    const dist = () => { const [a, b] = [...pts.values()]; return a && b ? Math.hypot(a.x - b.x, a.y - b.y) : 0; };
    const mid = (): O => { const v = [...pts.values()]; return { x: v.reduce((s, p) => s + p.x, 0) / v.length, y: v.reduce((s, p) => s + p.y, 0) / v.length }; };
    const down = (e: PointerEvent) => {
      const el = ref.current;
      if (!el || e.pointerType === 'mouse') return;
      if (!el.contains(e.target as Node) && pts.size === 0) return;
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pts.size === 2) g = { d0: dist(), s0: scale.current, m0: mid() };
    };
    const move = (e: PointerEvent) => {
      if (!pts.has(e.pointerId)) return;
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (!g || pts.size !== 2) return;
      const s = pinchScale(g.s0, g.d0, dist());
      if (s === scale.current) return;
      const el = ref.current;
      if (el && origin === 'pinch') {
        // keep the point between the fingers visually fixed while rescaling
        const m = mid();
        const s1 = scale.current;
        const o = orig.current ?? { x: el.offsetWidth / 2, y: el.offsetHeight / 2 };
        const r = el.getBoundingClientRect();
        // visual rect maps to local via V(p) = L + o(1-s1) + p·s1, so
        // L = rect.topleft - o(1-s1)
        const L = { x: r.left - o.x * (1 - s1), y: r.top - o.y * (1 - s1) };
        // local coords of the midpoint: solve L + o(1-s1) + p·s1 = m
        const p = { x: (m.x - L.x - o.x * (1 - s1)) / s1, y: (m.y - L.y - o.y * (1 - s1)) / s1 };
        // new origin o2 with L2 = L (layout unchanged): L + o2(1-s2) + p·s2 = m
        if (Math.abs(1 - s) > 0.02) {
          orig.current = { x: (m.x - L.x - p.x * s) / (1 - s), y: (m.y - L.y - p.y * s) / (1 - s) };
        }
      }
      scale.current = s;
      apply();
      cb.current?.(s);
    };
    const up = (e: PointerEvent) => {
      if (!pts.delete(e.pointerId)) return;
      if (pts.size < 2 && g) {
        g = null;
        try { localStorage.setItem(key, String(scale.current)); } catch { /* ignore */ }
      }
    };
    window.addEventListener('pointerdown', down, true);
    window.addEventListener('pointermove', move, true);
    window.addEventListener('pointerup', up, true);
    window.addEventListener('pointercancel', up, true);
    // re-apply after React re-renders swap the element (e.g. compact toggle)
    const mo = new MutationObserver(apply);
    if (ref.current?.parentElement) mo.observe(ref.current.parentElement, { childList: true });
    return () => {
      window.removeEventListener('pointerdown', down, true);
      window.removeEventListener('pointermove', move, true);
      window.removeEventListener('pointerup', up, true);
      window.removeEventListener('pointercancel', up, true);
      mo.disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ref, key, origin]);
}
