/* A color picker copy floating over the canvas in a little frosted-glass window.
 * Drag it by its grip; slide it into the bottom edge to remove it; pinch to resize.
 * The window is always clamped fully on screen — it can never hang off an edge. */
import { useCallback, useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { FloatingPickerFace, dragOrTap, type ColorTab, type Palette } from './ColorsSheet';
import type { HarmonyMode } from './color';
import { usePinchScale } from './pinch';

export type Floater = { id: string; tab: ColorTab | 'Palette'; x: number; y: number; paletteId?: string };
const REMOVE_ZONE = 70;
const MARGIN = 6;

type Props = {
  floater: Floater;
  /** follow this pointer right away (the copy was just pulled out of the window) */
  grabbed?: boolean;
  color: string; previous: string; recent: string[]; palettes: Palette[]; harmony: HarmonyMode; paletteView: 'Compact' | 'Cards';
  onChange: (hex: string) => void; onCommit: () => void;
  onMove: (x: number, y: number) => void; onRemove: () => void;
  onHarmony: (m: HarmonyMode) => void; onPalettes: (p: Palette[]) => void; onPaletteView: (v: 'Compact' | 'Cards') => void;
  onDragStart: (hex: string, e: { clientX: number; clientY: number }) => void;
};

/** Keeps a centered (translate:-50% -50%) element fully inside the viewport. */
const clampPos = (x: number, y: number, w: number, h: number) => ({
  x: Math.max(w / 2 + MARGIN, Math.min(window.innerWidth - w / 2 - MARGIN, x)),
  y: Math.max(h / 2 + MARGIN, Math.min(window.innerHeight - h / 2 - MARGIN, y)),
});

export function FloatingPicker(p: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPosState] = useState(() => clampPos(p.floater.x, p.floater.y, 240, 300));
  const posRef = useRef(pos); posRef.current = pos;
  const [dragging, setDragging] = useState(!!p.grabbed);
  const [doomed, setDoomed] = useState(false);
  const [leaving, setLeaving] = useState(false);
  const setPos = (v: { x: number; y: number }) => { posRef.current = v; setPosState(v); };

  const keepOnScreen = useCallback(() => {
    requestAnimationFrame(() => {
      const el = ref.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const next = clampPos(posRef.current.x, posRef.current.y, r.width, r.height);
      if (Math.abs(next.x - posRef.current.x) > 0.5 || Math.abs(next.y - posRef.current.y) > 0.5) { setPos(next); p.onMove(next.x, next.y); }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // clamp on mount, on window resize and after a pinch resize
  useEffect(() => {
    keepOnScreen();
    window.addEventListener('resize', keepOnScreen);
    return () => window.removeEventListener('resize', keepOnScreen);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  usePinchScale(ref, `pp.floatScale.${p.floater.id}`, 'pinch', keepOnScreen);

  const startDrag = (sx: number, sy: number, ox: number, oy: number) => {
    setDragging(true);
    let last = { x: ox, y: oy };
    const move = (e: PointerEvent) => {
      last = { x: ox + e.clientX - sx, y: oy + e.clientY - sy };
      setPos(last);
      setDoomed(e.clientY > window.innerHeight - REMOVE_ZONE);
    };
    const up = (e: PointerEvent) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      setDragging(false);
      if (e.clientY > window.innerHeight - REMOVE_ZONE) { setLeaving(true); window.setTimeout(p.onRemove, 260); return; }
      setDoomed(false);
      const r = ref.current?.getBoundingClientRect();
      const w = r?.width ?? 200, h = r?.height ?? 200;
      const c = clampPos(last.x, last.y, w, h);
      setPos(c);
      p.onMove(c.x, c.y);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
  };

  // freshly detached: it rides the finger until release
  useEffect(() => {
    if (p.grabbed) startDrag(p.floater.x, p.floater.y, p.floater.x, p.floater.y);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div ref={ref} className={`pp-floater ${dragging ? 'dragging' : ''} ${doomed ? 'doomed' : ''} ${leaving ? 'leaving' : ''}`}
      style={{ left: pos.x, top: pos.y }} role="dialog" aria-label={`Floating ${p.floater.tab} picker`}>
      <div className="pp-floater-grip" aria-label="Drag picker (slide to the bottom to remove)"
        onPointerDown={(e) => { e.preventDefault(); e.stopPropagation(); startDrag(e.clientX, e.clientY, pos.x, pos.y); }}>
        <span />
      </div>
      <div className="pp-floater-body" onPointerDown={(e) => e.stopPropagation()}>
        {p.floater.tab === 'Palette'
          ? <PaletteFloat p={p} />
          : <FloatingPickerFace tab={p.floater.tab} color={p.color} previous={p.previous} recent={p.recent} palettes={p.palettes} harmony={p.harmony}
              paletteView={p.paletteView} onTab={() => {}} onHarmony={p.onHarmony} onPaletteView={p.onPaletteView} onClearHistory={() => {}}
              onChange={p.onChange} onCommit={p.onCommit} onSwap={() => {}} onPalettes={p.onPalettes}
              onDragStart={(hex, e) => p.onDragStart(hex, e)} onClose={() => {}} />}
      </div>
      {doomed && <div className="pp-floater-bin">Release to remove</div>}
    </div>
  );
}

/** Picture-in-picture for a single palette: its swatches only. */
function PaletteFloat({ p }: { p: Props }) {
  const pal = p.palettes.find((x) => x.id === p.floater.paletteId) ?? p.palettes[0];
  if (!pal) return <div className="pp-pal-float-empty">No palette</div>;
  return (
    <div className="pp-pal-float">
      <span className="pp-pal-float-name">{pal.name}</span>
      <div className="pp-palette-grid">
        {pal.colors.length === 0 && <span className="pp-pal-float-empty">Empty palette</span>}
        {pal.colors.map((c, i) => (
          <Button key={i} variant="paint" size="paint" type="button" aria-label={`Swatch ${c}`} style={{ background: c }}
            onPointerDown={(e) => dragOrTap(e, () => { p.onChange(c); p.onCommit(); }, () => p.onDragStart(c, e))} />
        ))}
      </div>
    </div>
  );
}
