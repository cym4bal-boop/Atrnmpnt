// @ts-nocheck -- strict index checks relaxed for canvas pixel code.
import { describe, expect, it } from 'vitest';
import { harmonyColors, hexToHsv, hsvToHex } from './color';
import { detectShape } from './geometry';

describe('color conversions', () => {
  it('round-trips hex through HSV', () => {
    expect(hsvToHex(hexToHsv('#ffe6d9'))).toBe('#ffe6d9');
    expect(hsvToHex({ h: 0, s: 1, v: 1 })).toBe('#ff0000');
  });
  it('tetradic harmony gives three companions 90° apart', () => {
    expect(harmonyColors({ h: 20, s: 1, v: 1 }, 'Tetradic').map((c) => c.h)).toEqual([110, 200, 290]);
  });
  it('complementary harmony is the opposite hue', () => {
    expect(harmonyColors({ h: 300, s: 1, v: 1 }, 'Complementary')[0].h).toBe(120);
  });
});

describe('QuickShape', () => {
  it('snaps a straight-ish stroke to a line', () => {
    const pts = Array.from({ length: 20 }, (_, i) => ({ x: i * 10, y: i % 2 }));
    expect(detectShape(pts)?.kind).toBe('line');
  });
  it('snaps a round stroke to a circle', () => {
    const pts = Array.from({ length: 60 }, (_, i) => ({ x: 100 + 50 * Math.cos((i / 60) * Math.PI * 2), y: 100 + 50 * Math.sin((i / 60) * Math.PI * 2) }));
    const s = detectShape(pts);
    expect(s?.kind).toBe('ellipse');
    expect(s && s.kind === 'ellipse' && s.circle).toBe(true);
  });
});
