import { describe, expect, it } from 'vitest';
import { mapToPalette } from './palette-map';
import { pinchScale } from './pinch';

describe('apply palette to layer', () => {
  it('snaps every visible pixel to the nearest palette colour', () => {
    const d = new Uint8ClampedArray([250, 10, 10, 255, 10, 10, 240, 128]);
    mapToPalette(d, ['#ff0000', '#0000ff']);
    expect([...d]).toEqual([255, 0, 0, 255, 0, 0, 255, 128]);
  });
  it('leaves fully transparent pixels alone', () => {
    const d = new Uint8ClampedArray([12, 34, 56, 0]);
    mapToPalette(d, ['#ffffff']);
    expect([...d]).toEqual([12, 34, 56, 0]);
  });
});

describe('pinch to resize', () => {
  it('ignores small distance changes so two-finger drags never resize', () => {
    expect(pinchScale(1, 100, 105)).toBe(1);
  });
  it('clamps between 0.7x and 1.5x', () => {
    expect(pinchScale(1, 100, 400)).toBe(1.5);
    expect(pinchScale(1, 100, 10)).toBe(0.7);
  });
});
