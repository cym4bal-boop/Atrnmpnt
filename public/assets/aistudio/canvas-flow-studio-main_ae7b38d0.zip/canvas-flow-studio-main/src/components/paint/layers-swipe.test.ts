import { describe, expect, it } from 'vitest';
import { swipeIntent } from './LayersBar';

describe('layers bar one-finger swipe', () => {
  it('compacts when swiped toward the right edge while seated on the right', () => {
    expect(swipeIntent(120, 5, false)).toBe('compact');
  });
  it('expands when swiped away from the right edge', () => {
    expect(swipeIntent(-120, 5, false)).toBe('expand');
  });
  it('compacts when swiped toward the left edge while seated on the left', () => {
    expect(swipeIntent(-120, 5, true)).toBe('compact');
  });
  it('ignores short or mostly vertical moves', () => {
    expect(swipeIntent(20, 0, false)).toBeNull();
    expect(swipeIntent(60, 80, false)).toBeNull();
  });
});
