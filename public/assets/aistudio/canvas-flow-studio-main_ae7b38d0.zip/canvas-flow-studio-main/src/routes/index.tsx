import { ClientOnly, createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";

const PaintApp = lazy(() => import("@/components/paint/Studio"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Aeternum Paint — Digital Painting Studio" },
      { name: "description", content: "Paint, sketch and animate with layers, brushes and frames, right in your browser." },
      { property: "og:title", content: "Aeternum Paint — Digital Painting Studio" },
      { property: "og:description", content: "Paint, sketch and animate with layers, brushes and frames, right in your browser." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <ClientOnly fallback={null}>
      <Suspense fallback={null}>
        <PaintApp />
      </Suspense>
    </ClientOnly>
  );
}
