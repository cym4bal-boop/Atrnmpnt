import { describe, expect, it } from 'vitest';
import { moveRow, visibleRows, type TreeItem } from './layer-tree';

const L = (id: string, extra: Partial<TreeItem> = {}): TreeItem => ({ id, kind: 'pixel', ...extra });

describe('layer folders', () => {
  it('dropping a layer right under an open folder puts it inside', () => {
    const list: TreeItem[] = [L('a'), { id: 'g', kind: 'group' as const }, L('b')];
    const out = moveRow(list, 0, 1);
    expect(out.map((l) => l.id)).toEqual(['g', 'a', 'b']);
    expect(out[1]!.parent).toBe('g');
  });

  it('moving a folder carries its children along', () => {
    const list: TreeItem[] = [{ id: 'g', kind: 'group' as const }, L('c1', { parent: 'g' }), L('c2', { parent: 'g' }), L('x')];
    const out = moveRow(list, 0, 1);
    expect(out.map((l) => l.id)).toEqual(['x', 'g', 'c1', 'c2']);
  });

  it('folders never nest inside other folders', () => {
    const list: TreeItem[] = [{ id: 'g1', kind: 'group' as const }, L('c', { parent: 'g1' }), { id: 'g2', kind: 'group' as const }];
    const out = moveRow(list, 2, 1);
    expect(out.find((l) => l.id === 'g2')!.parent).toBeUndefined();
  });

  it('collapsed folders hide their children', () => {
    const list: TreeItem[] = [{ id: 'g', kind: 'group' as const, collapsed: true }, L('c', { parent: 'g' }), L('x')];
    expect(visibleRows(list).map((l) => l.id)).toEqual(['g', 'x']);
  });
});
